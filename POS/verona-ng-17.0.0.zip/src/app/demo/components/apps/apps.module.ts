import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppsRoutingModule } from './apps-routing.module';

@NgModule({
  imports: [
    CommonModule,
    AppsRoutingModule
  ],
  declarations: []
})
export class AppsModule { }
