import { MenuItem } from "primeng/api";

export interface TabCloseEvent {
    tab: MenuItem;
    index: number;
}